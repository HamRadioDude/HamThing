# Flex Thing v1.6 - Button Mapping Guide

## Quick Setup

Go to **DeskThing → Clients** page and configure mappings as follows:

## Rotary Wheel (VFO Tuning)

| Mode | Target | Action |
|------|--------|--------|
| **ScrollLeft** | Scroll | Tune Down |
| **ScrollRight** | Scroll | Tune Up |

### How to set up wheel:
1. Click **ScrollLeft** in the Modes bar at top
2. Drag **"Tune Down"** from the action bar to the **Scroll** area on the wheel
3. Click **ScrollRight** in the Modes bar at top  
4. Drag **"Tune Up"** from the action bar to the **Scroll** area on the wheel

## Dial Press (Enter)

| Target | Action |
|--------|--------|
| Enter | Cycle Tuning Step |

### How to set up dial press:
1. Drag **"Cycle Tuning Step"** to the **Enter** area

## Top Buttons - Recommended Setup

| Button | Action | Description |
|--------|--------|-------------|
| Digit1 | VFO Screen | Switch to VFO display |
| Digit2 | DSP Screen | Switch to DSP controls |
| Digit3 | Memory Screen | Switch to memory channels |
| Digit4 | TX Screen | Switch to TX power controls |

### Alternative: POTA Setup
| Button | Action | Description |
|--------|--------|-------------|
| Digit1-3 | (as above) | Screen switching |
| Digit4 | POTA Screen | Switch to POTA spots |

## Available Actions (All Rows)

### Nav Row
- **Screen Navigation**: VFO Screen, DSP Screen, Memory Screen, TX Screen, POTA Screen, Next Screen, Previous Screen
- **Antenna/ATU**: ATU Tune, Switch Antenna
- **Band Control**: Band Up, Band Down
- **DSP Controls**: Toggle NB, Toggle NR, Cycle AGC, NB Level Up/Down, NR Level Up/Down, Filter Wider/Narrower
- **VFO Controls**: Toggle Split, Swap A/B, A→B
- **RIT/XIT**: Toggle RIT, Toggle XIT, RIT Up/Down, RIT Clear

### Media Row  
- **Power/Audio**: Power Up, Power Down, Mic Gain Up/Down, Toggle VOX
- **Memory**: Memory 1-8
- **POTA**: Refresh POTA, POTA Scroll Up/Down

### All Row
- **Tuning**: Tune Up, Tune Down, Cycle Tuning Step, Cycle Mode
- **TX**: Toggle TX
- **Other**: Fullscreen, Hidden Button

## Screens

| Screen | Description |
|--------|-------------|
| **VFO** | Main frequency display, mode, S-meter |
| **DSP** | NB, NR, AGC, Filter controls |
| **MEM** | 8 memory channel buttons |
| **TX** | TX power control and PTT toggle |
| **POTA** | Live POTA spots filtered by current mode - tap to tune |

## Settings (App Configuration)

Configure in **DeskThing → Apps → Flex Thing → Settings**:

| Setting | Default | Description |
|---------|---------|-------------|
| Radio IP | (blank) | Manual IP or blank for auto-discovery |
| Default Step | 100 | Default tuning step in Hz |
| Memory 1-8 | various | Format: freq,mode,label |

## POTA Spots

The POTA screen shows live activator spots from pota.app:
- Spots are **filtered by your current mode** (USB shows SSB spots, DIGU shows FT8/FT4, etc.)
- **Tap a spot** to tune directly to that frequency
- Spots auto-refresh every 60 seconds
- Use **Refresh POTA** action for manual refresh

## Known Limitations

- **S-Meter**: Real-time S-meter updates require UDP VITA-49 streaming (not currently implemented). The meter display is static.

## Troubleshooting

### Wheel not working?
- Make sure BOTH ScrollLeft AND ScrollRight are mapped
- They are separate mappings - check each mode individually

### Buttons not responding?
- Make sure the action is dragged to the correct button slot
- Check the DeskThing logs for action triggers

### Radio not connecting?
- Check that SmartSDR is running
- Try setting the Radio IP manually in settings
- Check firewall isn't blocking port 4992

### POTA spots not loading?
- Check internet connectivity
- Try the Refresh button
- Check DeskThing server logs
