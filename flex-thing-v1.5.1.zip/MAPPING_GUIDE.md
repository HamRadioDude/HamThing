# Flex Thing v1.3 - Button Mapping Guide

## Quick Setup

Go to **DeskThing → Clients** page and configure mappings as follows:

## Rotary Wheel (VFO Tuning)

| Mode | Target | Action |
|------|--------|--------|
| **ScrollLeft** | Scroll | Tune Down |
| **ScrollRight** | Scroll | Tune Up |

### How to set up wheel:
1. Click **ScrollLeft** in the Modes bar at top
2. Drag **"Tune Down"** from the action bar to the **Scroll** area on the wheel
3. Click **ScrollRight** in the Modes bar at top  
4. Drag **"Tune Up"** from the action bar to the **Scroll** area on the wheel

## Dial Press (Enter)

| Target | Action |
|--------|--------|
| Enter | Cycle Tuning Step |

### How to set up dial press:
1. Drag **"Cycle Tuning Step"** to the **Enter** area

## Top Buttons (Physical Presets)

| Button | Action | Description |
|--------|--------|-------------|
| Button 1 (leftmost) | ATU Tune | Start antenna tuner |
| Button 2 | Switch Antenna | Cycle ANT1→ANT2→XVTR→RX_A→RX_B |
| Button 3 | Cycle Mode | Cycle USB→LSB→CW→AM→FM→DIGU→DIGL |
| Button 4 (rightmost) | Toggle NB | Toggle noise blanker |

### How to set up buttons:
1. Click on each button slot in the Car Thing diagram
2. Drag the corresponding action from the **Nav** row in the action bar

## Available Actions (All Rows)

### Nav Row
- ATU Tune
- Band Up / Band Down
- Switch Antenna
- Toggle NB / Toggle NR
- Cycle AGC
- NB Level Up/Down, NR Level Up/Down
- Filter Wider/Narrower
- Toggle Split, Swap A/B, A→B
- Toggle RIT/XIT, RIT Up/Down
- RIT Clear

### Media Row  
- Power Up / Power Down
- Mic Gain Up/Down
- Toggle VOX
- Memory 1-8
- Next/Previous Screen
- VFO/DSP/Memory/TX Screen

### All Row
- Tune Up / Tune Down
- Cycle Tuning Step
- Cycle Mode
- Toggle TX
- Fullscreen
- Hidden Button

## Settings (App Configuration)

Configure in **DeskThing → Apps → Flex Thing → Settings**:

| Setting | Default | Description |
|---------|---------|-------------|
| Radio IP | (blank) | Manual IP or blank for auto-discovery |
| Default Step | 100 | Default tuning step in Hz |
| Memory 1 | 14074000,USB,FT8 20m | Format: freq,mode,label |
| Memory 2 | 7074000,USB,FT8 40m | |
| Memory 3 | 3573000,USB,FT8 80m | |
| Memory 4 | 14300000,USB,SSB 20m | |

## Recommended Minimal Setup

If you just want basic tuning:

1. **ScrollLeft** → Scroll → "Tune Down"
2. **ScrollRight** → Scroll → "Tune Up"  
3. **Enter** → "Cycle Tuning Step"
4. **Button 3** → "Cycle Mode"

That's it! You can tune, change step size, and change modes.

## Troubleshooting

### Wheel not working?
- Make sure BOTH ScrollLeft AND ScrollRight are mapped
- They are separate mappings - check each mode individually

### Buttons not responding?
- Make sure the action is dragged to the correct button slot
- Check the DeskThing logs for action triggers

### Radio not connecting?
- Check that SmartSDR is running
- Try setting the Radio IP manually in settings
- Check firewall isn't blocking UDP port 4992
